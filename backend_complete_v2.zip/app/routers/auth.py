from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.orm import Session
from .. import schemas, models, database
from ..deps import get_password_hash, verify_password, create_access_token, get_current_user, require_admin

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/login", response_model=schemas.Token)
def login(request: schemas.LoginRequest, db: Session = Depends(database.get_db)):
    user = db.query(models.User).filter(models.User.email == request.email).first()
    if not user or not verify_password(request.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token({"sub": user.email, "role": user.role})
    return {"access_token": token, "token_type": "bearer"}

@router.post("/register/student", response_model=schemas.UserOut)
def register_student(payload: schemas.StudentCreate, db: Session = Depends(database.get_db)):
    if db.query(models.User).filter(models.User.email == payload.email).first():
        raise HTTPException(status_code=400, detail="Email already in use")
    user = models.User(
        full_name=payload.full_name,
        email=payload.email,
        hashed_password=get_password_hash(payload.password),
        role="student",
        code_apoge=payload.code_apoge,
        cne=payload.cne,
        stream_id=payload.stream_id,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

@router.post("/register/teacher", response_model=schemas.UserOut)
def register_teacher(payload: schemas.TeacherCreate, db: Session = Depends(database.get_db)):
    if db.query(models.User).filter(models.User.email == payload.email).first():
        raise HTTPException(status_code=400, detail="Email already in use")
    user = models.User(
        full_name=payload.full_name,
        email=payload.email,
        hashed_password=get_password_hash(payload.password),
        role="teacher",
        stream_id=payload.stream_id,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

@router.post("/create-admin", response_model=schemas.UserOut)
def create_admin(
    payload: schemas.AdminCreate,
    authorization: str = Header(None),
    db: Session = Depends(database.get_db),
):
    # Only admin (authenticated) can create another admin
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing token")
    token = authorization.split(" ", 1)[1]
    current = get_current_user(token, db)
    require_admin(current)

    if db.query(models.User).filter(models.User.email == payload.email).first():
        raise HTTPException(status_code=400, detail="Email already in use")
    user = models.User(
        full_name=payload.full_name,
        email=payload.email,
        hashed_password=get_password_hash(payload.password),
        role="admin",
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user
