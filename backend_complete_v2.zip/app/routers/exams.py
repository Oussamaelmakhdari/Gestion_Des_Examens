import io
import random
from fastapi import APIRouter, Depends, HTTPException, Header
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from .. import models, schemas, database
from ..deps import get_current_user

router = APIRouter(prefix="/exams", tags=["Exams"])

@router.post("/", response_model=schemas.ExamOut)
def create_exam(
    payload: schemas.ExamCreate,
    authorization: str = Header(None),
    db: Session = Depends(database.get_db),
):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing token")
    token = authorization.split(" ", 1)[1]
    current = get_current_user(token, db)
    if current.role != "admin":
        raise HTTPException(status_code=403, detail="Admins only")

    subject = db.query(models.Subject).filter(models.Subject.id == payload.subject_id).first()
    room = db.query(models.Room).filter(models.Room.id == payload.room_id).first()
    stream = db.query(models.Stream).filter(models.Stream.id == payload.stream_id).first()
    if not subject or not room or not stream:
        raise HTTPException(status_code=404, detail="Subject/Room/Stream not found")


    exam = models.Exam(
        subject_id=payload.subject_id,
        room_id=payload.room_id,
        stream_id=payload.stream_id,
        date=payload.date,
        time=payload.time,
        teacher_id=payload.teacher_id,
    )
    db.add(exam)
    db.commit()
    db.refresh(exam)
    return exam

@router.get("/stream/{stream_id}", response_model=list[schemas.ExamOut])
def list_exams(stream_id: int, db: Session = Depends(database.get_db)):
    return db.query(models.Exam).filter(models.Exam.stream_id == stream_id).all()

@router.get("/{exam_id}/convocation")
def download_convocation(
    exam_id: int,
    authorization: str = Header(None),
    db: Session = Depends(database.get_db),
):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing token")
    token = authorization.split(" ", 1)[1]
    student = get_current_user(token, db)
    if student.role != "student":
        raise HTTPException(status_code=403, detail="Students only")

    exam = db.query(models.Exam).filter(models.Exam.id == exam_id).first()
    if not exam:
        raise HTTPException(status_code=404, detail="Exam not found")

    conv = db.query(models.Convocation).filter_by(student_id=student.id, exam_id=exam.id).first()
    if not conv:
        conv = models.Convocation(
            student_id=student.id,
            exam_id=exam.id,
            table_number=random.randint(1, 80),
        )
        db.add(conv)
        db.commit()
        db.refresh(conv)

    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4

    p.setFont("Helvetica-Bold", 18)
    p.drawCentredString(width / 2, height - 80, "Université Ibn Zohr")
    p.setFont("Helvetica", 14)
    p.drawCentredString(width / 2, height - 110, "Convocation d'Examen")

    y = height - 160
    p.setFont("Helvetica", 12)
    p.drawString(80, y, f"Nom complet : {student.full_name}"); y -= 20
    p.drawString(80, y, f"CNE : {student.cne or '-'}"); y -= 20
    p.drawString(80, y, f"Code Apogée : {student.code_apoge or '-'}"); y -= 20
    p.drawString(80, y, f"Filière : {exam.stream.nom}"); y -= 20
    p.drawString(80, y, f"Matière : {exam.subject.name}"); y -= 20
    p.drawString(80, y, f"Salle : {exam.room.name}"); y -= 20
    p.drawString(80, y, f"Table : {conv.table_number}"); y -= 20
    p.drawString(80, y, f"Date : {exam.date.strftime('%d/%m/%Y')} à {exam.time.strftime('%H:%M')}")

    p.showPage()
    p.save()
    buffer.seek(0)
    return StreamingResponse(
        buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": "inline; filename=convocation.pdf"},
    )
