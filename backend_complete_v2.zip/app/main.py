from fastapi import FastAPI
from .database import engine, get_db
from . import models
from .routers import auth, streams, exams, users, rooms
from .seeds import seed_streams_subjects, seed_rooms, seed_default_admin

app = FastAPI(title="Exams Management API")

# Create tables
models.Base.metadata.create_all(bind=engine)

# Seed data
db = next(get_db())
seed_streams_subjects(db)
seed_rooms(db)
seed_default_admin(db)

# Routers
app.include_router(auth.router)
app.include_router(streams.router)
app.include_router(exams.router)
app.include_router(users.router)
app.include_router(rooms.router)

@app.get("/")
def root():
    return {"status": "ok"}
